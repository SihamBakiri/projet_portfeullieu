import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Application application = new Application();
            MedecinDataBase medecinDataBase = new MedecinDataBase();
            MainFrame mainFrame = new MainFrame(application, medecinDataBase);
            mainFrame.setVisible(true);
        });
    }
}

class Application {
    // Les méthodes et données spécifiques de l'application peuvent être ajoutées ici
}

class MainFrame extends JFrame {
    private Application application;
    private MedecinDataBase medecinDataBase;
    private JLabel labelNomMedecin;

    public MainFrame(Application application, MedecinDataBase medecinDataBase) {
        this.application = application;
        this.medecinDataBase = medecinDataBase;

        setTitle("Gestion de RDV");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelAccueil = new JPanel();
        panelAccueil.setBackground(Color.LIGHT_GRAY);
        panelAccueil.setPreferredSize(new Dimension(getWidth(), 50));
        JLabel labelAccueil = new JLabel("Bienvenue dans mon application gestion de rendez-vous");
        panelAccueil.add(labelAccueil);

        ImageIcon image3 = new ImageIcon("src/rdv.png");
        JButton btnPrendreRDV = new JButton("Prendre RDV", image3);

        ImageIcon image1 = new ImageIcon("src/patient.png");
        JButton btnAjouterPatient = new JButton("Ajouter Patient", image1);

        ImageIcon image2 = new ImageIcon("src/medecin.png");
        JButton btnChoisirMedecin = new JButton("Choisir Médecin", image2);

        btnAjouterPatient.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Afficher le dialogue patient de manière modale
                PatientDialog patientDialog = new PatientDialog(MainFrame.this);
                patientDialog.setModal(true);
                patientDialog.setVisible(true);
            }
        });

        btnChoisirMedecin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<String> medecins;
                medecins = (ArrayList<String>) medecinDataBase.getListeMedecins();

                if (medecins.isEmpty()) {
                    JOptionPane.showMessageDialog(MainFrame.this, "Aucun médecin disponible.");
                    return;
                }

                String[] medecinNames = medecins.toArray(new String[0]);

                String selectedMedecin = (String) JOptionPane.showInputDialog(
                        MainFrame.this,
                        "Choisissez un médecin :",
                        "Choix du Médecin",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        medecinNames,
                        medecinNames[0]
                );

                if (selectedMedecin != null) {
                    labelNomMedecin.setText("Médecin choisi : " + selectedMedecin);
                }
            }
        });

        JPanel panelBoutons = new JPanel();
        panelBoutons.setLayout(new FlowLayout());
        panelBoutons.add(btnAjouterPatient);
        panelBoutons.add(btnChoisirMedecin);
        panelBoutons.add(btnPrendreRDV);

        JPanel panelContact = new JPanel();
        panelContact.setBackground(Color.LIGHT_GRAY);
        panelContact.setPreferredSize(new Dimension(getWidth(), 50));
        JLabel labelContact = new JLabel("Pour nous contacter   tel: 06 58 00 21 57 mail: bakirisihem1997@gmail.com");
        panelContact.add(labelContact);

        JPanel panelMedecinChoisi = new JPanel();
        panelMedecinChoisi.setBackground(Color.WHITE);
        panelMedecinChoisi.setPreferredSize(new Dimension(getWidth(), 50));
        labelNomMedecin = new JLabel("Médecin choisi : ");
        panelMedecinChoisi.add(labelNomMedecin);

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.add(panelAccueil);
        panelPrincipal.add(panelBoutons);
        panelPrincipal.add(panelMedecinChoisi);
        panelPrincipal.add(panelContact);

        add(panelPrincipal);

        pack();
        setLocationRelativeTo(null);
    }
}
