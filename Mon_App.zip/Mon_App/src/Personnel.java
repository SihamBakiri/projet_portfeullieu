import java.util.Random;

public abstract class Personnel {
    // Attributs de classe
    private static int totalPersonnel = 0;
    private static String[] genders = {"Male", "Female", "Other"};

    // Attributs d'instance
    protected String personnelId;
    protected String name;
    protected int age;
    protected String gender;
    protected String department;
    protected double salary;
    protected String[] languagesSpoken;

    // Constructeur sans paramètre (valeurs aléatoires)
    public Personnel() {
        totalPersonnel++;
        this.personnelId = "EMP" + totalPersonnel;
        this.name = generateRandomName();
        this.age = new Random().nextInt(45) + 20; // Random age between 20 and 65
        this.gender = getRandomGender();
        this.department = "General";
        this.salary = 40000.0; // Default salary
        this.languagesSpoken = new String[]{"English"};
    }

    // Constructeur avec des paramètres spécifiques
    public Personnel(String name, int age, String gender, String department, double salary, String[] languagesSpoken) {
        totalPersonnel++;
        this.personnelId = "EMP" + totalPersonnel;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.salary = salary;
        this.languagesSpoken = languagesSpoken;
    }

    // Méthode d'instance abstraite pour afficher le rôle du personnel
    public abstract void displayRole();

    // Méthode d'instance pour obtenir l'ID du personnel
    public String getPersonnelId() {
        return personnelId;
    }

    // Méthode d'instance pour obtenir le salaire du personnel
    public double getSalary() {
        return salary;
    }

    // Méthode d'instance pour obtenir le nom du personnel
    public String getName() {
        return name;
    }

    // Méthode d'instance pour vérifier si le personnel parle une langue spécifique
    public boolean speaksLanguage(String language) {
        for (String spokenLanguage : languagesSpoken) {
            if (spokenLanguage.equalsIgnoreCase(language)) {
                return true;
            }
        }
        return false;
    }

    // Méthode d'instance pour générer un nom aléatoire (à des fins de démonstration)
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Michael", "Emily", "David", "Sophia"};
        String[] lastNames = {"Smith", "Johnson", "Brown", "Lee", "Wilson", "Wang"};
        return firstNames[new Random().nextInt(firstNames.length)] + " " + lastNames[new Random().nextInt(lastNames.length)];
    }

    // Méthode privée pour obtenir un genre aléatoire
    private String getRandomGender() {
        return genders[new Random().nextInt(genders.length)];
    }
}
