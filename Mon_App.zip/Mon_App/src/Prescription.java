import java.util.Random;
public class Prescription {
    // Attributs de classe
    private static int totalPrescriptions = 0;
    private static String[] availableMedications = {"Medication A", "Medication B", "Medication C"};
    private static String defaultDosageUnit = "mg";

    // Attributs d'instance
    private String prescriptionId;
    private String patientName;
    private String medicationName;
    private double dosage;
    private String dosageUnit;
    private String instructions;
    private String prescribingDoctor;
    private String pharmacy;
    private boolean isFulfilled;
    private String[] additionalNotes;

    // Constructeur sans paramètre (valeurs aléatoires)
    public Prescription(String consultation1, String[] strings, int[] ints) {
        totalPrescriptions++;
        this.prescriptionId = "RX" + totalPrescriptions;
        this.patientName = "Patient " + totalPrescriptions;
        this.medicationName = getRandomMedication();
        this.dosage = generateRandomDosage();
        this.dosageUnit = defaultDosageUnit;
        this.instructions = "Take as directed";
        this.prescribingDoctor = "Dr. Smith";
        this.pharmacy = "Pharmacy " + totalPrescriptions;
        this.isFulfilled = false;
        this.additionalNotes = new String[0];
    }

    // Constructeur avec des paramètres spécifiques
    public Prescription(String patientName, String medicationName, double dosage, String dosageUnit,
                        String instructions, String prescribingDoctor, String pharmacy, boolean isFulfilled) {
        totalPrescriptions++;
        this.prescriptionId = "RX" + totalPrescriptions;
        this.patientName = patientName;
        this.medicationName = medicationName;
        this.dosage = dosage;
        this.dosageUnit = dosageUnit;
        this.instructions = instructions;
        this.prescribingDoctor = prescribingDoctor;
        this.pharmacy = pharmacy;
        this.isFulfilled = isFulfilled;
        this.additionalNotes = new String[0];
    }

    // Constructeur avec un dictionnaire de données
    public Prescription(String prescriptionId, String patientName, String medicationName, double dosage,
                        String dosageUnit, String instructions, String prescribingDoctor, String pharmacy,
                        boolean isFulfilled, String[] additionalNotes) {
        totalPrescriptions++;
        this.prescriptionId = prescriptionId;
        this.patientName = patientName;
        this.medicationName = medicationName;
        this.dosage = dosage;
        this.dosageUnit = dosageUnit;
        this.instructions = instructions;
        this.prescribingDoctor = prescribingDoctor;
        this.pharmacy = pharmacy;
        this.isFulfilled = isFulfilled;
        this.additionalNotes = additionalNotes;
    }

    // Constructeur avec seulement le nom du patient et le médicament
    public Prescription(String patientName, String medicationName) {
        totalPrescriptions++;
        this.prescriptionId = "RX" + totalPrescriptions;
        this.patientName = patientName;
        this.medicationName = medicationName;
        this.dosage = generateRandomDosage();
        this.dosageUnit = defaultDosageUnit;
        this.instructions = "Take as directed";
        this.prescribingDoctor = "Dr. Smith";
        this.pharmacy = "Pharmacy " + totalPrescriptions;
        this.isFulfilled = false;
        this.additionalNotes = new String[0];
    }

    // Constructeur avec seulement l'ID de la prescription
    public Prescription(String prescriptionId) {
        totalPrescriptions++;
        this.prescriptionId = prescriptionId;
        this.patientName = "Patient " + totalPrescriptions;
        this.medicationName = getRandomMedication();
        this.dosage = generateRandomDosage();
        this.dosageUnit = defaultDosageUnit;
        this.instructions = "Take as directed";
        this.prescribingDoctor = "Dr. Smith";
        this.pharmacy = "Pharmacy " + totalPrescriptions;
        this.isFulfilled = false;
        this.additionalNotes = new String[0];
    }

    // Méthode de classe pour obtenir le nombre total de prescriptions
    public static int getTotalPrescriptions() {
        return totalPrescriptions;
    }

    // Méthode de classe pour définir l'unité de dosage par défaut
    public static void setDefaultDosageUnit(String unit) {
        defaultDosageUnit = unit;
    }

    // Méthode de classe pour obtenir l'unité de dosage par défaut
    public static String getDefaultDosageUnit() {
        return defaultDosageUnit;
    }

    // Méthode d'instance pour ajouter une note additionnelle à la prescription
    public void addAdditionalNote(String note) {
        // Implémentation de la logique pour ajouter une note additionnelle
    }

    // Méthode d'instance pour vérifier si la prescription est remplie
    public boolean isFulfilled() {
        return isFulfilled;
    }

    // Méthode d'instance pour afficher les informations de la prescription
    public void displayPrescriptionInformation() {
        // Implémentation de la logique pour afficher les informations de la prescription
    }

    // Méthode d'instance pour calculer la posologie totale pour une durée donnée
    public double calculateTotalDosageForDuration(int durationDays) {
        // Implémentation de la logique pour calculer la posologie totale
        // en fonction de la durée de traitement (en jours)
        return dosage * durationDays;
    }

    // ... (autres méthodes d'instance)

    // Méthode privée pour obtenir un médicament aléatoire
    private String getRandomMedication() {
        return availableMedications[new Random().nextInt(availableMedications.length)];
    }

    // Méthode privée pour générer une posologie aléatoire (à des fins de démonstration)
    private double generateRandomDosage() {
        return new Random().nextDouble() * 10.0; // Random dosage between 0.0 and 10.0
    }

    public void displayPrescription() {
    }
}
