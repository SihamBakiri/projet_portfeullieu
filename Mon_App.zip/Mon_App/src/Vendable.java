public interface Vendable {
    double calculerPrix();
    void afficherDetails();
}
