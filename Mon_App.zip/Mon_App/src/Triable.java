public interface Triable {
    void trier();
}
