import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PatientDialog extends JDialog {
    private JTextField txtNom;
    private JTextField txtPrenom;
    private JTextField txtAge;
    private JTextField txtSexe;
    private JTextField txtIdPatient;
    private JTextField txtGroupeSanguin;

    private JButton btnSave;
    private JButton btnCancel;

    public PatientDialog(JFrame parent) {
        super(parent, "Ajouter Patient", true);
        setLayout(new GridLayout(7, 2));

        // Créer les champs de texte pour les informations du patient
        JLabel labelNom = new JLabel("Nom:");
        txtNom = new JTextField();
        JLabel labelPrenom = new JLabel("Prénom:");
        txtPrenom = new JTextField();
        JLabel labelAge = new JLabel("Âge:");
        txtAge = new JTextField();
        JLabel labelSexe = new JLabel("Sexe:");
        txtSexe = new JTextField();
        JLabel labelIdPatient = new JLabel("ID Patient:");
        txtIdPatient = new JTextField();
        JLabel labelGroupeSanguin = new JLabel("Groupe Sanguin:");
        txtGroupeSanguin = new JTextField();

        // Créer les boutons Enregistrer et Annuler
        btnSave = new JButton("Enregistrer");
        btnCancel = new JButton("Annuler");

        // Ajouter les composants à la fenêtre de dialogue
        add(labelNom);
        add(txtNom);
        add(labelPrenom);
        add(txtPrenom);
        add(labelAge);
        add(txtAge);
        add(labelSexe);
        add(txtSexe);
        add(labelIdPatient);
        add(txtIdPatient);
        add(labelGroupeSanguin);
        add(txtGroupeSanguin);
        add(btnSave);
        add(btnCancel);

        // Définir un gestionnaire d'événements pour le bouton "Enregistrer"
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Récupérer les informations saisies par l'utilisateur
                String nom = txtNom.getText();
                String prenom = txtPrenom.getText();
                int age = Integer.parseInt(txtAge.getText());
                String sexe = txtSexe.getText();
                int idPatient = Integer.parseInt(txtIdPatient.getText());
                String groupeSanguin = txtGroupeSanguin.getText();

                // Enregistrer les informations du patient dans la base de données (à implémenter)
                // Ici, nous allons simplement afficher les informations pour le moment
                String message = "Patient ajouté avec succès : \n" +
                        "Nom: " + nom + "\n" +
                        "Prénom: " + prenom + "\n" +
                        "Âge: " + age + "\n" +
                        "Sexe: " + sexe + "\n" +
                        "ID Patient: " + idPatient + "\n" +
                        "Groupe Sanguin: " + groupeSanguin;
                JOptionPane.showMessageDialog(PatientDialog.this, message);

                // Fermer la fenêtre de dialogue après l'enregistrement
                dispose();
            }
        });

        // Définir un gestionnaire d'événements pour le bouton "Annuler"
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Fermer la fenêtre de dialogue sans enregistrer les informations
                dispose();
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }
}
