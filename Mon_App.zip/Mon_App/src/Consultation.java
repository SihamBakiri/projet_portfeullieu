import java.util.Date;

public abstract class Consultation {
    // Attributs de classe
    private static int totalConsultations = 0;

    // Attributs d'instance
    protected String consultationId;
    protected Date date;
    protected String patientId;
    protected String medecinId;
    protected boolean isCompleted;
    protected String diagnosis;

    // Constructeur sans paramètre
    public Consultation() {
        totalConsultations++;
        this.consultationId = "CONS" + totalConsultations;
        this.date = new Date(); // Date actuelle par défaut
        this.patientId = "";
        this.medecinId = "";
        this.isCompleted = false;
        this.diagnosis = "";
    }

    // Constructeur avec des paramètres spécifiques
    public Consultation(Date date, String patientId, String medecinId) {
        totalConsultations++;
        this.consultationId = "CONS" + totalConsultations;
        this.date = date;
        this.patientId = patientId;
        this.medecinId = medecinId;
        this.isCompleted = false;
        this.diagnosis = "";
    }

    // Méthode d'instance abstraite pour afficher les détails de la consultation
    public abstract void displayConsultationDetails();

    // Méthode d'instance pour marquer la consultation comme complétée
    public void completeConsultation(String diagnosis) {
        this.isCompleted = true;
        this.diagnosis = diagnosis;
    }

    // Méthode d'instance pour obtenir l'ID de la consultation
    public String getConsultationId() {
        return consultationId;
    }

    // Méthode d'instance pour vérifier si la consultation est complétée
    public boolean isCompleted() {
        return isCompleted;
    }

    // Méthode d'instance pour obtenir la date de la consultation
    public Date getDate() {
        return date;
    }

    // Méthode d'instance pour obtenir l'ID du patient
    public String getPatientId() {
        return patientId;
    }

    // Méthode d'instance pour obtenir l'ID du médecin
    public String getMedecinId() {
        return medecinId;
    }
}

