import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SalleAttente {
    // Attributs de classe
    private static int totalSalles = 0;
    private static int maxCapacity = 20;
    private static List<String> waitingRoomList = new ArrayList<>();

    // Attributs d'instance
    private String salleId;
    private int currentCapacity;
    private boolean isFull;
    private String[] patientsInQueue;
    private String receptionistName;
    private String doctorName;
    private boolean isEmergencyRoom;
    private String location;
    private String phoneNumber;
    private String email;

    // Constructeur sans paramètre (valeurs aléatoires)
    public SalleAttente(String s, int i, boolean b) {
        totalSalles++;
        this.salleId = "SA" + totalSalles;
        this.currentCapacity = new Random().nextInt(maxCapacity) + 1; // Random capacity between 1 and maxCapacity
        this.isFull = (this.currentCapacity == maxCapacity);
        this.patientsInQueue = new String[0];
        this.receptionistName = "Receptionist " + totalSalles;
        this.doctorName = "Dr. Smith";
        this.isEmergencyRoom = false;
        this.location = "Location " + totalSalles;
        this.phoneNumber = "N/A";
        this.email = "N/A";
    }

    // Constructeur avec des paramètres spécifiques
    public SalleAttente(int currentCapacity, boolean isEmergencyRoom, String location, String phoneNumber, String email) {
        totalSalles++;
        this.salleId = "SA" + totalSalles;
        this.currentCapacity = currentCapacity;
        this.isFull = (this.currentCapacity == maxCapacity);
        this.patientsInQueue = new String[0];
        this.receptionistName = "Receptionist " + totalSalles;
        this.doctorName = "Dr. Smith";
        this.isEmergencyRoom = isEmergencyRoom;
        this.location = location;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    // Constructeur avec un dictionnaire de données
    public SalleAttente(String salleId, int currentCapacity, boolean isEmergencyRoom, String[] patientsInQueue,
                        String receptionistName, String doctorName, String location, String phoneNumber, String email) {
        totalSalles++;
        this.salleId = salleId;
        this.currentCapacity = currentCapacity;
        this.isFull = (this.currentCapacity == maxCapacity);
        this.patientsInQueue = patientsInQueue;
        this.receptionistName = receptionistName;
        this.doctorName = doctorName;
        this.isEmergencyRoom = isEmergencyRoom;
        this.location = location;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    // Constructeur avec seulement le nom de la salle d'attente
    public SalleAttente(String location) {
        totalSalles++;
        this.salleId = "SA" + totalSalles;
        this.currentCapacity = new Random().nextInt(maxCapacity) + 1; // Random capacity between 1 and maxCapacity
        this.isFull = (this.currentCapacity == maxCapacity);
        this.patientsInQueue = new String[0];
        this.receptionistName = "Receptionist " + totalSalles;
        this.doctorName = "Dr. Smith";
        this.isEmergencyRoom = false;
        this.location = location;
        this.phoneNumber = "N/A";
        this.email = "N/A";
    }

    // Constructeur avec seulement l'ID de la salle d'attente
    public SalleAttente(String salleId, String location) {
        totalSalles++;
        this.salleId = salleId;
        this.currentCapacity = new Random().nextInt(maxCapacity) + 1; // Random capacity between 1 and maxCapacity
        this.isFull = (this.currentCapacity == maxCapacity);
        this.patientsInQueue = new String[0];
        this.receptionistName = "Receptionist " + totalSalles;
        this.doctorName = "Dr. Smith";
        this.isEmergencyRoom = false;
        this.location = location;
        this.phoneNumber = "N/A";
        this.email = "N/A";
    }

    // Méthode de classe pour obtenir le nombre total de salles d'attente
    public static int getTotalSalles() {
        return totalSalles;
    }

    // Méthode de classe pour définir la capacité maximale de la salle d'attente
    public static void setMaxCapacity(int capacity) {
        maxCapacity = capacity;
    }

    // Méthode de classe pour obtenir la capacité maximale de la salle d'attente
    public static int getMaxCapacity() {
        return maxCapacity;
    }

    // Méthode d'instance pour ajouter un patient à la file d'attente
    public void addPatientToQueue(String patientName) {
        // Implémentation de la logique pour ajouter un patient à la file d'attente
    }

    // Méthode d'instance pour afficher les informations de la salle d'attente
    public void displayWaitingRoomInformation() {
        // Implémentation de la logique pour afficher les informations de la salle d'attente
    }

    // Méthode d'instance pour trier les patients dans la file d'attente par ordre alphabétique
    public void sortPatientsInQueue() {
        // Implémentation de la logique pour trier les patients dans la file d'attente
    }

    // Méthode d'instance pour vérifier si la salle d'attente est pleine
    public boolean isFull() {
        return isFull;
    }

    // Méthode d'instance pour vérifier si la salle d'attente est une salle d'urgence
    public boolean isEmergencyRoom() {
        return isEmergencyRoom;
    }

    // Méthode d'instance pour rechercher un patient dans la file d'attente
    public boolean searchPatientInQueue(String patientName) {
        // Implémentation de la logique pour rechercher un patient dans la file d'attente
        return false;
    }

    // Méthode privée pour générer un nom aléatoire (à des fins de démonstration)
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Michael", "Emily", "David", "Sophia"};
        String[] lastNames = {"Smith", "Johnson", "Brown", "Lee", "Wilson", "Wang"};
        return firstNames[new Random().nextInt(firstNames.length)] + " " + lastNames[new Random().nextInt(lastNames.length)];
    }

    // Méthode privée pour obtenir un genre aléatoire
    private String getRandomGender() {
        String[] genders = {"Male", "Female", "Other"};
        return genders[new Random().nextInt(genders.length)];
    }

    public void displaySalleAttenteInformation() {
    }
}

