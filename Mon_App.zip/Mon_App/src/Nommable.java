public interface Nommable {
    String getNom();
}
