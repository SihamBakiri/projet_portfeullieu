
import java.util.ArrayList;
import java.util.List;

public class MedecinDataBase {
    // Simulation d'une base de données contenant une liste de médecins
    private List<String> medecins;

    public MedecinDataBase() {
        // Initialisation de la liste des médecins
        medecins = new ArrayList<>();
        medecins.add("Dr. Smith");
        medecins.add("Dr. Johnson");
        medecins.add("Dr. Williams");
        medecins.add("Dr. Lee");
        // ... Ajouter d'autres médecins ici si nécessaire
    }

    public List<String> getListeMedecins() {
        // Renvoie la liste des médecins
        return medecins;
    }
    // Nouvelle méthode pour obtenir la liste des médecins sous forme d'ArrayList
    public ArrayList<String> getAllMedecins() {
        return new ArrayList<>(medecins);
    }
}
