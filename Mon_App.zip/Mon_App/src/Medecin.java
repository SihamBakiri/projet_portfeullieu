import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Medecin implements Nommable{
    // Attributs de classe
    private static int totalMedecins = 0;
    private static int maxPatientsPerMedecin = 30;
    private static String defaultSpeciality = "Généraliste";

    // Attributs d'instance
    private String medecinId;
    private String name;
    private int age;
    private String gender;
    private String speciality;
    private List<String> patients;
    private int yearsOfExperience;
    private boolean isAvailable;
    private double consultationFee;
    private String hospitalName;
    private String[] languagesSpoken;

    // Constructeur sans paramètre (valeurs aléatoires)
    public Medecin() {
        totalMedecins++;
        this.medecinId = "M" + totalMedecins;
        this.name = generateRandomName();
        this.age = new Random().nextInt(40) + 30; // Random age between 30 and 70
        this.gender = new Random().nextBoolean() ? "Male" : "Female";
        this.speciality = defaultSpeciality;
        this.patients = new ArrayList<>();
        this.yearsOfExperience = new Random().nextInt(40);
        this.isAvailable = true;
        this.consultationFee = 100.0;
        this.hospitalName = "General Hospital";
        this.languagesSpoken = new String[]{"English", "French"};
    }

    // Constructeur avec des paramètres spécifiques
    public Medecin(String name, int age, String gender, String speciality, int yearsOfExperience, double consultationFee, String hospitalName, String[] languagesSpoken) {
        totalMedecins++;
        this.medecinId = "M" + totalMedecins;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.speciality = speciality;
        this.patients = new ArrayList<>();
        this.yearsOfExperience = yearsOfExperience;
        this.isAvailable = true;
        this.consultationFee = consultationFee;
        this.hospitalName = hospitalName;
        this.languagesSpoken = languagesSpoken;
    }

    // Constructeur avec un dictionnaire de données
    public Medecin(String name, int age, String gender, String speciality, int yearsOfExperience, boolean isAvailable, double consultationFee, String hospitalName, String[] languagesSpoken) {
        totalMedecins++;
        this.medecinId = "M" + totalMedecins;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.speciality = speciality;
        this.patients = new ArrayList<>();
        this.yearsOfExperience = yearsOfExperience;
        this.isAvailable = isAvailable;
        this.consultationFee = consultationFee;
        this.hospitalName = hospitalName;
        this.languagesSpoken = languagesSpoken;
    }

    // Constructeur avec seulement le nom et l'âge
    public Medecin(String name, int age) {
        totalMedecins++;
        this.medecinId = "M" + totalMedecins;
        this.name = name;
        this.age = age;
        this.gender = "Unknown";
        this.speciality = defaultSpeciality;
        this.patients = new ArrayList<>();
        this.yearsOfExperience = 0;
        this.isAvailable = true;
        this.consultationFee = 100.0;
        this.hospitalName = "General Hospital";
        this.languagesSpoken = new String[]{"English", "French"};
    }

    // Constructeur avec le nom, l'âge et l'expérience
    public Medecin(String name, int age, int yearsOfExperience) {
        totalMedecins++;
        this.medecinId = "M" + totalMedecins;
        this.name = name;
        this.age = age;
        this.gender = "Unknown";
        this.speciality = defaultSpeciality;
        this.patients = new ArrayList<>();
        this.yearsOfExperience = yearsOfExperience;
        this.isAvailable = true;
        this.consultationFee = 100.0;
        this.hospitalName = "General Hospital";
        this.languagesSpoken = new String[]{"English", "French"};
    }
    public Medecin(String name, int age, String speciality) {
        totalMedecins++;
        this.name = name;
        this.age = age;
        this.speciality = speciality;

    }
    // Méthode de classe pour obtenir le nombre maximum de patients par médecin
    public static int getMaxPatientsPerMedecin() {
        return maxPatientsPerMedecin;
    }

    // Méthode de classe pour définir la spécialité par défaut
    public static void setDefaultSpeciality(String defaultSpeciality) {
        Medecin.defaultSpeciality = defaultSpeciality;
    }

    // Méthode de classe pour obtenir la spécialité par défaut
    public static String getDefaultSpeciality() {
        return defaultSpeciality;
    }

    // Méthode d'instance pour ajouter un patient au médecin
    public void addPatient(String patientId) {
        if (patients.size() < maxPatientsPerMedecin) {
            patients.add(patientId);
        } else {
            System.out.println("Le médecin a atteint sa capacité maximale de patients.");
        }
    }

    // Méthode d'instance pour vérifier si le médecin parle une langue spécifique
    public boolean speaksLanguage(String language) {
        for (String spokenLanguage : languagesSpoken) {
            if (spokenLanguage.equalsIgnoreCase(language)) {
                return true;
            }
        }
        return false;
    }

    // Méthode d'instance pour obtenir le nombre de patients du médecin
    public int getPatientCount() {
        return patients.size();
    }

    // Méthode d'instance pour obtenir le revenu mensuel du médecin
    public double getMonthlyIncome() {
        return consultationFee * patients.size();
    }

    // Méthode d'instance pour générer un nom aléatoire (à des fins de démonstration)
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Michael", "Emily", "David", "Sophia"};
        String[] lastNames = {"Smith", "Johnson", "Brown", "Lee", "Wilson", "Wang"};
        return firstNames[new Random().nextInt(firstNames.length)] + " " + lastNames[new Random().nextInt(lastNames.length)];
    }

    @Override
    public String getNom() {
        return null;
    }

    public void displayMedecinInformation() {
    }
}
