import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Patient implements Connectable, Triable{
    // Attributs de classe
    private static int totalPatients = 0;
    private static int organDonorCount = 0;
    private static int healthRecordSystemVersion = 2;
    public String getName;

    // Attributs d'instance
    private String patientId;
    private String name;
    private int age;
    private String gender;
    private String bloodType;
    private boolean isOrganDonor;
    private List<String> medicalHistory;

    // Constructeur sans paramètre (valeurs aléatoires)
    public Patient(String alice, int age, int i, String male) {
        totalPatients++;
        this.patientId = "P" + totalPatients;
        this.name = generateRandomName();
        this.age = new Random().nextInt(63) + 18; // Random age between 18 and 80
        this.gender = new Random().nextBoolean() ? "Male" : "Female";
        this.bloodType = getRandomBloodType();
        this.isOrganDonor = false;
        this.medicalHistory = new ArrayList<>();
    }

    // Constructeur avec des paramètres spécifiques
    public Patient(String name, int age, String gender, String bloodType) {
        totalPatients++;
        this.patientId = "P" + totalPatients;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.bloodType = bloodType;
        this.isOrganDonor = false;
        this.medicalHistory = new ArrayList<>();
    }

    // Constructeur avec un dictionnaire de données
    public Patient(String name, int age, String gender, String bloodType, boolean isOrganDonor, List<String> medicalHistory) {
        totalPatients++;
        this.patientId = "P" + totalPatients;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.bloodType = bloodType;
        this.isOrganDonor = isOrganDonor;
        this.medicalHistory = medicalHistory;
    }

    // Méthode de classe pour compter les donneurs d'organes
    public static void incrementOrganDonorCount() {
        organDonorCount++;
    }

    // Méthode de classe pour obtenir la version du système d'enregistrement médical
    public static int getHealthRecordSystemVersion() {
        return healthRecordSystemVersion;
    }

    // Méthode de classe pour réinitialiser le compteur de donneurs d'organes
    public static void resetOrganDonorCount() {
        organDonorCount = 0;
    }

    // Méthode d'instance pour ajouter une entrée à l'historique médical
    public void addMedicalEntry(String entry) {
        medicalHistory.add(entry);
    }

    // Méthode d'instance pour vérifier si le patient est majeur
    public boolean isAdult() {
        return age >= 18;
    }

    // Méthode d'instance pour vérifier si le patient est éligible pour donner des organes
    public boolean isEligibleOrganDonor() {
        return isAdult() && !isOrganDonor;
    }

    // Méthode d'instance pour obtenir le groupe sanguin complet du patient
    public String getFullBloodType() {
        if (bloodType.equals("O")) {
            return bloodType + "+";
        } else {
            return bloodType + (new Random().nextBoolean() ? "+" : "-");
        }
    }

    // Méthode d'instance pour générer un nom aléatoire (à des fins de démonstration)
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Michael", "Emily", "David", "Sophia"};
        String[] lastNames = {"Smith", "Johnson", "Brown", "Lee", "Wilson", "Wang"};
        return firstNames[new Random().nextInt(firstNames.length)] + " " + lastNames[new Random().nextInt(lastNames.length)];
    }

    // Méthode privée pour obtenir un groupe sanguin aléatoire
    private String getRandomBloodType() {
        String[] bloodTypes = {"A", "B", "AB", "O"};
        return bloodTypes[new Random().nextInt(bloodTypes.length)];
    }

    @Override
    public void seConnecter() {

    }

    @Override
    public void seDeconnecter() {

    }

    @Override
    public void trier() {

    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public void displayPatientInformation() {
    }

    public Object getGender() {
        return this.gender;
    }

    public String getPatientId() {
        return this.patientId ;
    }
    }


