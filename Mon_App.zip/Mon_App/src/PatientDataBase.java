import java.util.ArrayList;

public class PatientDataBase {
    private ArrayList<Patient> patients;

    public PatientDataBase() {
        patients = new ArrayList<>();
    }

    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    public ArrayList<Patient> getAllPatients() {
        return patients;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Patient patient : patients) {
            sb.append(patient).append("\n");
        }
        return sb.toString();
    }
}
