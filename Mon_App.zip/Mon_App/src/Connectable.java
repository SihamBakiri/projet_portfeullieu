public interface Connectable {
    void seConnecter();
    void seDeconnecter();
}

