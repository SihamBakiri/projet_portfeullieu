
import java.util.Date;
public abstract class Facture implements Imprimable{

    // Attributs de classe
    private static int totalFactures = 0;

    // Attributs d'instance
    protected String factureId;
    protected Date date;
    protected String patientId;
    protected double montant;
    protected boolean estPayee;

    // Constructeur sans paramètre
    public Facture() {
        totalFactures++;
        this.factureId = "FACT" + totalFactures;
        this.date = new Date(); // Date actuelle par défaut
        this.patientId = "";
        this.montant = 0.0;
        this.estPayee = false;
    }

    // Constructeur avec des paramètres spécifiques
    public Facture(Date date, String patientId, double montant) {
        totalFactures++;
        this.factureId = "FACT" + totalFactures;
        this.date = date;
        this.patientId = patientId;
        this.montant = montant;
        this.estPayee = false;
    }

    // Méthode d'instance abstraite pour afficher les détails de la facture
    public abstract void afficherDetailsFacture();

    // Méthode d'instance pour marquer la facture comme payée
    public void marquerCommePayee() {
        this.estPayee = true;
    }

    // Méthode d'instance pour obtenir l'ID de la facture
    public String getFactureId() {
        return factureId;
    }

    // Méthode d'instance pour vérifier si la facture est payée
    public boolean estPayee() {
        return estPayee;
    }

    // Méthode d'instance pour obtenir la date de la facture
    public Date getDate() {
        return date;
    }

    // Méthode d'instance pour obtenir l'ID du patient
    public String getPatientId() {
        return patientId;
    }

    // Méthode d'instance pour obtenir le montant de la facture
    public double getMontant() {
        return montant;
    }
}
