import java.sql.Timestamp;
import java.util.Date;
import java.util.Random;

public class DossierPatient implements Triable{
    // Attributs de classe
    private static int totalDossiers = 0;
    private static String[] bloodTypes = {"A", "B", "AB", "O"};

    // Attributs d'instance
    private String dossierId;
    private String patientName;
    private int patientAge;
    private Date patientBirthdate;
    private String patientGender;
    private String patientBloodType;
    private String address;
    private String phoneNumber;
    private String emailAddress;
    private String[] allergies;
    private String[] medicalHistory;

    // Constructeur sans paramètre (valeurs aléatoires)
    public DossierPatient() {
        totalDossiers++;
        this.dossierId = "DP" + totalDossiers;
        this.patientName = generateRandomName();
        this.patientAge = new Random().nextInt(70) + 1; // Random age between 1 and 70
        this.patientBirthdate = generateRandomBirthdate();
        this.patientGender = getRandomGender();
        this.patientBloodType = getRandomBloodType();
        this.address = "N/A";
        this.phoneNumber = "N/A";
        this.emailAddress = "N/A";
        this.allergies = new String[0];
        this.medicalHistory = new String[0];
    }

    // Constructeur avec des paramètres spécifiques
    public DossierPatient(String patientName, int patientAge, Date patientBirthdate, String patientGender,
                          String patientBloodType, String address, String phoneNumber, String emailAddress) {
        totalDossiers++;
        this.dossierId = "DP" + totalDossiers;
        this.patientName = patientName;
        this.patientAge = patientAge;
        this.patientBirthdate = patientBirthdate;
        this.patientGender = patientGender;
        this.patientBloodType = patientBloodType;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.allergies = new String[0];
        this.medicalHistory = new String[0];
    }

    // Constructeur avec un dictionnaire de données
    public DossierPatient(String dossierId, String patientName, int patientAge, Date patientBirthdate,
                          String patientGender, String patientBloodType, String address,
                          String phoneNumber, String emailAddress, String[] allergies, String[] medicalHistory) {
        totalDossiers++;
        this.dossierId = dossierId;
        this.patientName = patientName;
        this.patientAge = patientAge;
        this.patientBirthdate = patientBirthdate;
        this.patientGender = patientGender;
        this.patientBloodType = patientBloodType;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.allergies = allergies;
        this.medicalHistory = medicalHistory;
    }

    // Constructeur avec seulement le nom et l'âge du patient
    public DossierPatient(String patientName, int patientAge) {
        totalDossiers++;
        this.dossierId = "DP" + totalDossiers;
        this.patientName = patientName;
        this.patientAge = patientAge;
        this.patientBirthdate = generateRandomBirthdate();
        this.patientGender = getRandomGender();
        this.patientBloodType = getRandomBloodType();
        this.address = "N/A";
        this.phoneNumber = "N/A";
        this.emailAddress = "N/A";
        this.allergies = new String[0];
        this.medicalHistory = new String[0];
    }

    // Constructeur avec seulement l'ID du dossier
    public DossierPatient(String dossierId) {
        totalDossiers++;
        this.dossierId = dossierId;
        this.patientName = generateRandomName();
        this.patientAge = new Random().nextInt(70) + 1; // Random age between 1 and 70
        this.patientBirthdate = generateRandomBirthdate();
        this.patientGender = getRandomGender();
        this.patientBloodType = getRandomBloodType();
        this.address = "N/A";
        this.phoneNumber = "N/A";
        this.emailAddress = "N/A";
        this.allergies = new String[0];
        this.medicalHistory = new String[0];
    }

    // Méthode de classe pour obtenir le nombre total de dossiers
    public static int getTotalDossiers() {
        return totalDossiers;
    }
        // Méthode de classe pour définir le groupe sanguin par défaut
        public static void setDefaultBloodType(String defaultBloodType) {
            if (isValidBloodType(defaultBloodType)) {
                DossierPatient.bloodTypes[0] = defaultBloodType;
            } else {
                System.out.println("Invalid blood type provided. Default blood type not changed.");
            }
        }

        // Méthode de classe pour vérifier la validité d'un groupe sanguin
        private static boolean isValidBloodType(String bloodType) {
            for (String validType : bloodTypes) {
                if (validType.equalsIgnoreCase(bloodType)) {
                    return true;
                }
            }
            return false;
        }

    // Méthode d'instance pour ajouter une allergie au dossier patient
    public void addAllergy(String allergy) {
        // Implémentation de la logique pour ajouter une allergie
    }

    // Méthode d'instance pour ajouter un élément à l'historique médical
    public void addToMedicalHistory(String entry) {
        // Implémentation de la logique pour ajouter un élément à l'historique médical
    }

    // Méthode d'instance pour afficher les informations du dossier patient
    public void displayPatientInformation() {
        // Implémentation de la logique pour afficher les informations du dossier patient
    }

    // Méthode d'instance pour vérifier si le patient est majeur
    public boolean isAdult() {
        return patientAge >= 18;
    }

    // Méthode privée pour générer un nom aléatoire (à des fins de démonstration)
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Michael", "Emily", "David", "Sophia"};
        String[] lastNames = {"Smith", "Johnson", "Brown", "Lee", "Wilson", "Wang"};
        return firstNames[new Random().nextInt(firstNames.length)] + " " + lastNames[new Random().nextInt(lastNames.length)];
    }

    // Méthode privée pour générer une date de naissance aléatoire (à des fins de démonstration)
    private Date generateRandomBirthdate() {
        long offset = Timestamp.valueOf("1970-01-01 00:00:00").getTime();
        long end = Timestamp.valueOf("2005-01-01 00:00:00").getTime();
        long diff = end - offset + 1;
        return new Date(offset + (long)(Math.random() * diff));
    }

    // Méthode privée pour obtenir un genre aléatoire
    // Méthode privée pour obtenir un genre aléatoire
    private String getRandomGender() {
        String[] genders = {"Male", "Female", "Other"};
        return genders[new Random().nextInt(genders.length)];
    }

    // Méthode privée pour obtenir un groupe sanguin aléatoire
    private static String getRandomBloodType() {
        return bloodTypes[new Random().nextInt(bloodTypes.length)];
    }

    // Méthode d'instance pour afficher les allergies du patient
    public void displayAllergies() {
        // Implémentation de la logique pour afficher les allergies du patient
    }

    // Méthode d'instance pour afficher l'historique médical du patient
    public void displayMedicalHistory() {
        // Implémentation de la logique pour afficher l'historique médical du patient
    }

    @Override
    public void trier() {

    }
}
