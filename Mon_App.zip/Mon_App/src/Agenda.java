import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public abstract class Agenda {
    // Attributs de classe
    private static int totalAgendas = 0;
    protected static int maxAppointmentsPerDay = 10;
    protected static int maxDaysInAdvance = 30;

    // Attributs d'instance
    protected String agendaId;
    protected String medecinId;
    protected List<Date> appointments;
    protected String[] workingDays;
    protected int maxAppointmentsPerPatient;
    protected int daysInAdvance;

    // Constructeur sans paramètre (valeurs aléatoires)
    public Agenda() {
        totalAgendas++;
        this.agendaId = "AGENDA" + totalAgendas;
        this.medecinId = "";
        this.appointments = new ArrayList<>();
        this.workingDays = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        this.maxAppointmentsPerPatient = 2;
        this.daysInAdvance = new Random().nextInt(maxDaysInAdvance) + 1;
        generateRandomAppointments();
    }

    // Constructeur avec des paramètres spécifiques
    public Agenda(String medecinId, String[] workingDays, int maxAppointmentsPerPatient, int daysInAdvance) {
        totalAgendas++;
        this.agendaId = "AGENDA" + totalAgendas;
        this.medecinId = medecinId;
        this.appointments = new ArrayList<>();
        this.workingDays = workingDays;
        this.maxAppointmentsPerPatient = maxAppointmentsPerPatient;
        this.daysInAdvance = daysInAdvance;
        generateRandomAppointments();
    }

    // Constructeur avec un dictionnaire de données
    public Agenda(String medecinId, List<Date> appointments, String[] workingDays, int maxAppointmentsPerPatient, int daysInAdvance) {
        totalAgendas++;
        this.agendaId = "AGENDA" + totalAgendas;
        this.medecinId = medecinId;
        this.appointments = appointments;
        this.workingDays = workingDays;
        this.maxAppointmentsPerPatient = maxAppointmentsPerPatient;
        this.daysInAdvance = daysInAdvance;
    }

    // Constructeur avec seulement l'ID du médecin
    public Agenda(String medecinId) {
        totalAgendas++;
        this.agendaId = "AGENDA" + totalAgendas;
        this.medecinId = medecinId;
        this.appointments = new ArrayList<>();
        this.workingDays = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        this.maxAppointmentsPerPatient = 2;
        this.daysInAdvance = new Random().nextInt(maxDaysInAdvance) + 1;
        generateRandomAppointments();
    }

    // Constructeur avec seulement l'ID du médecin et le nombre d'appels maximum par patient
    public Agenda(String medecinId, int maxAppointmentsPerPatient) {
        totalAgendas++;
        this.agendaId = "AGENDA" + totalAgendas;
        this.medecinId = medecinId;
        this.appointments = new ArrayList<>();
        this.workingDays = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        this.maxAppointmentsPerPatient = maxAppointmentsPerPatient;
        this.daysInAdvance = new Random().nextInt(maxDaysInAdvance) + 1;
        generateRandomAppointments();
    }

    // Méthode de classe pour obtenir le nombre maximum de rendez-vous par jour
    public static int getMaxAppointmentsPerDay() {
        return maxAppointmentsPerDay;
    }

    // Méthode de classe pour définir le nombre maximum de rendez-vous par jour
    public static void setMaxAppointmentsPerDay(int maxAppointmentsPerDay) {
        Agenda.maxAppointmentsPerDay = maxAppointmentsPerDay;
    }

    // Méthode de classe pour obtenir le nombre de jours en avance pour la prise de rendez-vous
    public static int getMaxDaysInAdvance() {
        return maxDaysInAdvance;
    }

    // Méthode de classe pour définir le nombre de jours en avance pour la prise de rendez-vous
    public static void setMaxDaysInAdvance(int maxDaysInAdvance) {
        Agenda.maxDaysInAdvance = maxDaysInAdvance;
    }

    // Méthode d'instance pour afficher les rendez-vous du jour
    public void displayAppointmentsForDay(Date date) {
        // Implémentation de la logique pour afficher les rendez-vous du jour
    }

    // Méthode d'instance pour prendre un nouveau rendez-vous
    public void scheduleAppointment(Date date, String patientId) {
        // Implémentation de la logique pour prendre un rendez-vous
    }

    // Méthode d'instance pour annuler un rendez-vous
    public void cancelAppointment(Date date) {
        // Implémentation de la logique pour annuler un rendez-vous
    }

    // Méthode d'instance pour vérifier si le médecin travaille un jour donné
    public boolean isWorkingDay(String day) {
        for (String workingDay : workingDays) {
            if (workingDay.equalsIgnoreCase(day)) {
                return true;
            }
        }
        return false;
    }

    // Méthode d'instance pour générer des rendez-vous aléatoires pour l'agenda
    private void generateRandomAppointments() {
        // Implémentation de la logique pour générer des rendez-vous aléatoires
    }
}
