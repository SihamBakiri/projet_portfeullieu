public interface Imprimable {
    void imprimer();
}

