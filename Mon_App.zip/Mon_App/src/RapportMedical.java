import java.util.Random;

public class RapportMedical {
    // Attributs de classe
    private static int totalRapports = 0;
    private static String[] possibleDiagnoses = {"Cold", "Flu", "Fever", "Allergies", "Headache"};
    private static String defaultDoctor = "Dr. Smith";

    // Attributs d'instance
    private String rapportId;
    private String patientName;
    private int patientAge;
    private String patientGender;
    private String doctorName;
    private String diagnosis;
    private String[] symptoms;
    private String[] medications;
    private String notes;
    private String treatmentPlan;

    // Constructeur sans paramètre (valeurs aléatoires)
    public RapportMedical() {
        totalRapports++;
        this.rapportId = "RM" + totalRapports;
        this.patientName = "Patient " + totalRapports;
        this.patientAge = new Random().nextInt(70) + 1; // Random age between 1 and 70
        this.patientGender = getRandomGender();
        this.doctorName = defaultDoctor;
        this.diagnosis = getRandomDiagnosis();
        this.symptoms = new String[0];
        this.medications = new String[0];
        this.notes = "N/A";
        this.treatmentPlan = "N/A";
    }

    // Constructeur avec des paramètres spécifiques
    public RapportMedical(String patientName, int patientAge, String patientGender, String doctorName,
                          String diagnosis, String[] symptoms, String[] medications, String notes, String treatmentPlan) {
        totalRapports++;
        this.rapportId = "RM" + totalRapports;
        this.patientName = patientName;
        this.patientAge = patientAge;
        this.patientGender = patientGender;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
        this.symptoms = symptoms;
        this.medications = medications;
        this.notes = notes;
        this.treatmentPlan = treatmentPlan;
    }

    // Constructeur avec un dictionnaire de données
    public RapportMedical(String rapportId, String patientName, int patientAge, String patientGender,
                          String doctorName, String diagnosis, String[] symptoms, String[] medications,
                          String notes, String treatmentPlan) {
        totalRapports++;
        this.rapportId = rapportId;
        this.patientName = patientName;
        this.patientAge = patientAge;
        this.patientGender = patientGender;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
        this.symptoms = symptoms;
        this.medications = medications;
        this.notes = notes;
        this.treatmentPlan = treatmentPlan;
    }

    // Constructeur avec seulement le nom du patient et le diagnostic
    public RapportMedical(String patientName, String diagnosis) {
        totalRapports++;
        this.rapportId = "RM" + totalRapports;
        this.patientName = patientName;
        this.patientAge = new Random().nextInt(70) + 1; // Random age between 1 and 70
        this.patientGender = getRandomGender();
        this.doctorName = defaultDoctor;
        this.diagnosis = diagnosis;
        this.symptoms = new String[0];
        this.medications = new String[0];
        this.notes = "N/A";
        this.treatmentPlan = "N/A";
    }

    // Constructeur avec seulement l'ID du rapport
    public RapportMedical(String rapportId) {
        totalRapports++;
        this.rapportId = rapportId;
        this.patientName = "Patient " + totalRapports;
        this.patientAge = new Random().nextInt(70) + 1; // Random age between 1 and 70
        this.patientGender = getRandomGender();
        this.doctorName = defaultDoctor;
        this.diagnosis = getRandomDiagnosis();
        this.symptoms = new String[0];
        this.medications = new String[0];
        this.notes = "N/A";
        this.treatmentPlan = "N/A";
    }

    // Méthode de classe pour obtenir le nombre total de rapports médicaux
    public static int getTotalRapports() {
        return totalRapports;
    }

    // Méthode de classe pour définir le médecin par défaut
    public static void setDefaultDoctor(String doctor) {
        defaultDoctor = doctor;
    }

    // Méthode de classe pour obtenir le médecin par défaut
    public static String getDefaultDoctor() {
        return defaultDoctor;
    }

    // Méthode d'instance pour ajouter un symptôme au rapport médical
    public void addSymptom(String symptom) {
        // Implémentation de la logique pour ajouter un symptôme
    }

    // Méthode d'instance pour ajouter un médicament prescrit au rapport médical
    public void addMedication(String medication) {
        // Implémentation de la logique pour ajouter un médicament prescrit
    }

    // Méthode d'instance pour afficher les informations du rapport médical
    public void displayReportInformation() {
        // Implémentation de la logique pour afficher les informations du rapport médical
    }

    // Méthode d'instance pour générer un plan de traitement pour le patient
    public String generateTreatmentPlan() {
        // Implémentation de la logique pour générer un plan de traitement
        return "Start with rest and drink plenty of fluids.";
    }

    // ... (autres méthodes d'instance)

    // Méthode privée pour obtenir un genre aléatoire
    private String getRandomGender() {
        String[] genders = {"Male", "Female", "Other"};
        return genders[new Random().nextInt(genders.length)];
    }

    // Méthode privée pour obtenir un diagnostic aléatoire
    private String getRandomDiagnosis() {
        return possibleDiagnoses[new Random().nextInt(possibleDiagnoses.length)];
    }
}

